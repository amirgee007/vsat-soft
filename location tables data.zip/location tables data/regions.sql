-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2017 at 06:30 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reg`
--

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `region_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`region_id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Africa', 0, NULL, NULL),
(2, 'Antarctic', 0, NULL, NULL),
(3, 'Arctic', 0, NULL, NULL),
(4, 'Asia', 0, NULL, NULL),
(5, 'Australasia', 0, NULL, NULL),
(6, 'Balkans', 0, NULL, NULL),
(7, 'Baltic States', 0, NULL, NULL),
(8, 'Caribbean', 0, NULL, NULL),
(9, 'Central Africa', 0, NULL, NULL),
(10, 'Central America', 0, NULL, NULL),
(11, 'Central Asia', 0, NULL, NULL),
(12, 'Central Europe', 0, NULL, NULL),
(13, 'East Africa', 0, NULL, NULL),
(14, 'East Asia', 0, NULL, NULL),
(15, 'Eastern Europe', 0, NULL, NULL),
(16, 'East Indies', 0, NULL, NULL),
(17, 'Eurasia', 0, NULL, NULL),
(18, 'Europe', 0, NULL, NULL),
(19, 'Far East', 0, NULL, NULL),
(20, 'Indian Subcontinent', 0, NULL, NULL),
(21, 'Indochina', 0, NULL, NULL),
(22, 'Latin America', 0, NULL, NULL),
(23, 'Melanesia', 0, NULL, NULL),
(24, 'Meso-America', 0, NULL, NULL),
(25, 'Middle East', 0, NULL, NULL),
(26, 'Micronesia', 0, NULL, NULL),
(27, 'New World', 0, NULL, NULL),
(28, 'North Africa', 0, NULL, NULL),
(29, 'North America', 0, NULL, NULL),
(30, 'Northern Europe', 0, NULL, NULL),
(31, 'Occident', 0, NULL, NULL),
(32, 'Oceania', 0, NULL, NULL),
(33, 'Orient', 0, NULL, NULL),
(34, 'Polynesia', 0, NULL, NULL),
(35, 'Scandinavia', 0, NULL, NULL),
(36, 'South America', 0, NULL, NULL),
(37, 'Southeast Asia', 0, NULL, NULL),
(38, 'Southern Africa', 0, NULL, NULL),
(39, 'Southern Asia', 0, NULL, NULL),
(40, 'Southern Europe', 0, NULL, NULL),
(41, 'South Pacific', 0, NULL, NULL),
(42, 'Sub-Saharan Africa', 0, NULL, NULL),
(43, 'Transcaucasia', 0, NULL, NULL),
(44, 'West Africa', 0, NULL, NULL),
(45, 'Western Europe', 0, NULL, NULL),
(46, 'West Indies', 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`region_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `region_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
